# alertacrypto-deploy
Deploy do sistema de alerta cripto usando Flask e Render.
